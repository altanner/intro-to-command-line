grep horse *
ls
head -n 2 romeo*

